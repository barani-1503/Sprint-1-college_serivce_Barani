package com.tns.collegeservice;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="student")

public class CollegeEntity {
	//data member
	@Id
	@Column(name="Sid")
	private int Sid;
	@Column(name="Sname")
	private String name;
	@Column(name="dept")
	private String dept;
	@Column(name="placfee")
	private int placfee;
	//getter setter methods
	public int getSid() {
		return Sid;
	}
	public void setSid(int sid) {
		Sid = sid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getPlacfee() {
		return placfee;
	}
	public void setPlacfee(int placfee) {
		this.placfee = placfee;
	}
	
	
	public CollegeEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CollegeEntity(int sid, String name, String dept, int placfee) {
		super();
		Sid = sid;
		this.name = name;
		this.dept = dept;
		this.placfee = placfee;
	}
	@Override
	public String toString() {
		return "CollegeEntity [Sid=" + Sid + ", name=" + name + ", dept=" + dept + ", placfee=" + placfee + "]";
	}
	
	

}
