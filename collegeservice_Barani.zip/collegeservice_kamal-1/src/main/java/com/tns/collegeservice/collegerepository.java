package com.tns.collegeservice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface collegerepository extends JpaRepository <CollegeEntity,Integer>
{
	
}
	


