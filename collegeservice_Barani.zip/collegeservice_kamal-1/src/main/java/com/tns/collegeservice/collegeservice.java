package com.tns.collegeservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional

public class collegeservice {
	@Autowired
	private  collegerepository service_repo;
	//to display all record from table
    public List<CollegeEntity> listAll(){
    	return service_repo.findAll();
    }
    //to insert new record
    public void save(CollegeEntity s) {
    	service_repo.save(s);
    }
    //to get the specific record
    public CollegeEntity get(Integer id) {
    	return service_repo.findById(id).get();
    }
    //to delete the record
    public void delete(Integer id) {
    	 service_repo.deleteById(id);
    }

}
